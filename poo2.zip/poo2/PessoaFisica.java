// package poo2;
import java.time.LocalDate;
public class PessoaFisica extends Cliente{
	private String CPF;
	private String RG;
	private LocalDate dataNasc;
	public PessoaFisica(String nome, String email, String telefone, String endereço, String CPF,

			String RG, LocalDate dataNasc){
		super(nome, telefone, email, endereço);
		this.CPF = CPF;
		this.RG = RG;
		this.dataNasc = dataNasc;
	}
	public String getCPF() {
		return CPF;
	}
	public void setCPF(String CPF) {
		this.CPF = CPF;
	}
	public String getRG() {
		return RG;
	}
	public void setRG(String RG) {
		this.RG = RG;
	}
	public LocalDate getDataNasc() {
		return dataNasc;
	}
	public void setDataNasc(LocalDate dataNasc) {
		this.dataNasc = dataNasc;
	}
}