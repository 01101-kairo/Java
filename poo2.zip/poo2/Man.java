// package poo2;
import javax.swing.JOptionPane;
/*
 *Realize a implementação da herança em Java. A superclasse deve conter um método
 *construtor que inicializa os valores dos atributos e um método que apresenta os
 *dados do objeto armazenado, além dos métodos get e set. As classes filhas devem
 *conter atributos específicos, faça a sobrescrita do método que apresenta os dados
 *do objeto nas classes filhas.
 */

public class Man {
	public static void main(String[] args) {
		Cliente cliente;
			String nome = JOptionPane.showInputDialog("Nome:");
			String telefone = JOptionPane.showInputDialog("Telefone:");
			String email = JOptionPane.showInputDialog("email:");
			String endereço = JOptionPane.showInputDialog("endereço:");
			
		cliente = new Cliente(nome, telefone, email, endereço);
		cliente.getDados();
	}
}
